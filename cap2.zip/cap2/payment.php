<!DOCTYPE html>
<html>
<head>
    <title>Payment Page</title>
    <style>
        body {
            background-color: #f1f1f1;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 4px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-top: 100px;
        }

        h1 {
            text-align: center;
            color: #0a2b43;
            margin-bottom: 20px;
        }

        .back-button {
            text-align: center;
            margin-top: 20px;
        }

        .back-button a {
            color: #0a2b43;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Payment Page</h1>
        <div id="paypal-button-container"></div>
        <div class="back-button">
            <a href="javascript:history.back()">Back</a>
        </div>
    </div>

    <script src="https://www.paypal.com/sdk/js?client-id=Ad6j6KmLMms0qrMg3_PVMl_6xy6ZxW5px9SJ-HEpYGrU8T7zNOQKm60b8vio2Z2KFJOJ9Eprxtc4yOxi&currency=USD"></script>
    <script>
        // Render the PayPal button into #paypal-button-container
        paypal.Buttons({
            createOrder: function(data, actions) {
                // This function sets up the details of the transaction, including the amount and line item details.
                return actions.order.create({
                    purchase_units: [{
                        amount: {
                            value: '10.00' // Enter the payment amount here
                        }
                    }]
                });
            },
            onApprove: function(data, actions) {
                // This function captures the funds from the transaction.
                return actions.order.capture().then(function(details) {
                    // Here, you can handle the successful payment confirmation.
                    // You can update the database, send email notifications, etc.
                    console.log('Payment completed successfully!');
                    // Redirect the user to a success page
                    window.location.href = 'payment_success.php';
                });
            }
        }).render('#paypal-button-container');
    </script>
</body>
</html>

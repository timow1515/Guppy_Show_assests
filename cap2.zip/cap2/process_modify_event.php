<?php
// Include the database connection code here
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_cs2";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve the event ID from the form data
$event_id = $_POST['event_id'];

// Update event details in the database
$sql = "UPDATE events SET title = ?, description = ?, max_participants = ?, payment_amount = ?, organizer_name = ?, category = ? WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssissi", $_POST['title'], $_POST['description'], $_POST['max_participants'], $_POST['payment_amount'], $_POST['organizer_name'], $_POST['category'], $event_id);
$stmt->execute();

// Update participants
$participants = $_POST['participants'];

// Delete all existing participants for the event
$delete_sql = "DELETE FROM participants WHERE event_id = ?";
$delete_stmt = $conn->prepare($delete_sql);
$delete_stmt->bind_param("i", $event_id);
$delete_stmt->execute();

// Insert new participants
$insert_sql = "INSERT INTO participants (event_id, participant_name) VALUES (?, ?)";
$insert_stmt = $conn->prepare($insert_sql);
$insert_stmt->bind_param("is", $event_id, $participant_name);

foreach ($participants as $participant_name) {
    $insert_stmt->execute();
}

$stmt->close();
$delete_stmt->close();
$insert_stmt->close();
$conn->close();

// Redirect to the modified event page or any other desired location
header("Location: modify_event.php?event_id=" . $event_id);
exit();
?>

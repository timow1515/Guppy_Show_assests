<?php
// Handle the payment processing logic here
// Process the form data received from the payment page
// Perform necessary actions to process the payment

// Assuming the payment processing is successful, set the success parameter to true
$success = true;

// Redirect the user back to the payment page with the success parameter in the URL
header('Location: payment_page.php?success=' . ($success ? 'true' : 'false'));
exit();
?>

<?php
session_start();

// Connect to the database
$servername = 'localhost';
$db_username = 'root';
$db_password = '';
$dbname = 'db_cs2';

$conn = new mysqli($servername, $db_username, $db_password, $dbname);
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

// Retrieve user information
$email = $_SESSION['username'];
$sql = "SELECT * FROM users WHERE email = '$email'";
$result = $conn->query($sql);

// Handle the case when user information is not found
// Redirect or display an error message
if ($result->num_rows === 0) {
    echo "User information not found.";
    exit();
}

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $name = $row['firstname'];
    $address = $row['address'];
    $contactNumber = $row['contact_number'];
    // ... retrieve other columns as needed

    // Store the profile picture file path in a session variable
    $_SESSION['profile_picture'] = 'uploads/' . $row['profile_picture'];
}

// Handle profile picture upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['profile_picture'])) {
    $targetDir = 'uploads/';
    $targetFile = $targetDir . basename($_FILES['profile_picture']['name']);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    // Check if the file is an actual image
    $check = getimagesize($_FILES['profile_picture']['tmp_name']);
    if ($check !== false) {
        $uploadOk = 1;
    } else {
        echo 'Error: Invalid image file.';
        $uploadOk = 0;
    }

    // Check file size
    if ($_FILES['profile_picture']['size'] > 500000) {
        echo 'Error: Image file size is too large.';
        $uploadOk = 0;
    }

    // Allow only certain file formats
    $allowedFormats = ['jpg', 'jpeg', 'png'];
    if (!in_array($imageFileType, $allowedFormats)) {
        echo 'Error: Only JPG, JPEG, and PNG files are allowed.';
        $uploadOk = 0;
    }

    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk === 0) {
        echo 'Error: Profile picture was not uploaded.';
    } else {
        if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $targetFile)) {
            // Update the session variable with the new profile picture file path
            $_SESSION['profile_picture'] = $targetFile;
            echo 'Profile picture has been uploaded successfully.';
        } else {
            echo 'Error: There was an error uploading the profile picture.';
        }
    }
}

// Update profile information
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['name']) && isset($_POST['address']) && isset($_POST['contact_number'])) {
    $newName = $_POST['name'];
    $newAddress = $_POST['address'];
    $newContactNumber = $_POST['contact_number'];

    $sqlUpdate = "UPDATE users SET firstname='$newName', address='$newAddress', contact_number='$newContactNumber' WHERE email='$email'";
    if ($conn->query($sqlUpdate) === true) {
        echo '<p class="success-message">Profile information has been updated successfully.</p>';
        $name = $newName;
        $address = $newAddress;
        $contactNumber = $newContactNumber;
    } else {
        echo '<p class="error-message">Error: Unable to update profile information.</p>';
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Profile</title>
    <style>
        body {
            background-color: #f2f2f2;
            font-family: Arial, sans-serif;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ccc;
        }

        h1 {
            text-align: center;
            margin-top: 0;
        }

        .profile-picture {
            text-align: center;
            margin-bottom: 20px;
        }

        .profile-picture img {
            width: 200px;
            height: 200px;
            border-radius: 50%;
            object-fit: cover;
            object-position: center;
        }

        .profile-information {
            margin-bottom: 20px;
        }

        .profile-information label {
            font-weight: bold;
        }

        .profile-information input[type="text"],
        .profile-information input[type="email"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: none;
            border-radius: 4px;
            background-color: #f2f2f2;
        }

        .profile-information input[type="submit"] {
            width: auto;
            padding: 10px 20px;
            margin-top: 10px;
            background-color: #3498db;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .profile-information input[type="submit"]:hover {
            background-color: #2980b9;
        }

        .profile-information p.success-message {
            color: #4caf50;
        }

        .profile-information p.error-message {
            color: #f44336;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>User Profile</h1>

        <div class="profile-picture">
            <?php
            // Display the uploaded profile picture if available
            if (isset($_SESSION['profile_picture']) && file_exists($_SESSION['profile_picture'])) {
                echo '<img src="' . $_SESSION['profile_picture'] . '" alt="Profile Picture">';
            }
            ?>
        </div>

        <div class="profile-information">
            <form action="user_profile.php" method="POST" enctype="multipart/form-data">
                <label for="name">Name:</label>
                <input type="text" name="name" value="<?php echo $name; ?>" required><br>

                <label for="address">Address:</label>
                <input type="text" name="address" value="<?php echo $address; ?>" required><br>

                <label for="email">Email:</label>
                <input type="email" name="email" value="<?php echo $email; ?>" disabled><br>

                <label for="contact_number">Contact Number:</label>
                <input type="text" name="contact_number" value="<?php echo $contactNumber; ?>" required><br>

                <label for="profile_picture">Profile Picture:</label>
                <input type="file" name="profile_picture" accept="image/*"><br>

                <input type="submit" value="Update Profile">
            </form>

            <?php
            if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['name']) && isset($_POST['address']) && isset($_POST['contact_number'])) {
    $newName = $_POST['name'];
    $newAddress = $_POST['address'];
    $newContactNumber = $_POST['contact_number'];

    $sqlUpdate = "UPDATE users SET firstname = '$newName', address = '$newAddress', contact_number = '$newContactNumber' WHERE email = '$email'";
    
    if ($conn->query($sqlUpdate) === true) {
        echo '<p class="success-message">Profile information has been updated successfully.</p>';
        // Update the session variables with the new values
        $_SESSION['name'] = $newName;
        $_SESSION['address'] = $newAddress;
        $_SESSION['contact_number'] = $newContactNumber;
    } else {
        echo '<p class="error-message">Error: Unable to update profile information.</p>';
    }
}

            ?>
        </div>

        <p><a href="home_lobby.php">Back to Home Lobby</a></p>
    </div>
</body>
</html>

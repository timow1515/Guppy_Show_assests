<?php
session_start();



// Connect to the database
$servername = 'localhost';
$db_username = 'root';
$db_password = '';
$dbname = 'db_cs2';

$conn = new mysqli($servername, $db_username, $db_password, $dbname);
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

// Retrieve user information
$email = $_SESSION['email'];
$sql = "SELECT * FROM users WHERE email = '$email'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $name = $row['name'];
    $address = $row['address'];
    // ... retrieve other columns as needed
} else {
    // Handle the case when user information is not found
    // Redirect or display an error message
}

$conn->close();

// Handle profile picture upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['profile_picture'])) {
    $target_dir = 'profile_pictures/';
    $target_file = $target_dir . basename($_FILES['profile_picture']['name']);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check if the file is an actual image
    $check = getimagesize($_FILES['profile_picture']['tmp_name']);
    if ($check !== false) {
        // Check if the file already exists, then delete it
        if (file_exists($target_file)) {
            unlink($target_file);
        }

        // Move the uploaded file to the target directory
        if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $target_file)) {
            // File uploaded successfully, update the user's profile picture in the database
            $sql = "UPDATE users SET profile_picture = '$target_file' WHERE email = '$email'";
            if ($conn->query($sql) === true) {
                // Profile picture updated successfully
            } else {
                // Handle the case when profile picture update fails
            }
        } else {
            // Handle the case when file upload fails
        }
    } else {
        // Handle the case when the file is not an image
    }
}

// Handle profile information update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['name']) && isset($_POST['address'])) {
    $newName = $_POST['name'];
    $newAddress = $_POST['address'];

    // Update the user's information in the database
    $sql = "UPDATE users SET name = '$newName', address = '$newAddress' WHERE email = '$email'";
    if ($conn->query($sql) === true) {
        // User information updated successfully
        $name = $newName;
        $address = $newAddress;
    } else {
        // Handle the case when user information update fails
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Profile</title>
    <style>
        body {
            background-color: #f1f1f1;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }

        h1 {
            text-align: center;
            color: #0a2b43;
            margin-bottom: 20px;
        }

        .profile-picture {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 20px;
        }

        .profile-picture img {
            width: 200px;
            height: 200px;
            border-radius: 50%;
        }

        .profile-picture input[type="file"] {
            margin-left: 10px;
        }

        .profile-form label {
            font-weight: bold;
        }

        .profile-form input[type="text"],
        .profile-form textarea {
            width: 100%;
            padding: 5px;
            margin-bottom: 10px;
        }

        .profile-form input[type="submit"] {
            background-color: #0a2b43;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .home-lobby-button {
            text-align: center;
        }

        .home-lobby-button a {
            display: inline-block;
            padding: 10px 20px;
            background-color: #0a2b43;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }

        .home-lobby-button a:hover {
            background-color: #064976;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>User Profile</h1>

        <div class="profile-picture">
            <img src="<?php echo $row['profile_picture']; ?>" alt="Profile Picture">
            <form action="user_profile.php" method="POST" enctype="multipart/form-data">
                <input type="file" name="profile_picture">
                <input type="submit" value="Upload">
            </form>
        </div>

        <form class="profile-form" action="user_profile.php" method="POST">
            <label for="name">Name:</label>
            <input type="text" name="name" value="<?php echo $name; ?>" required>
            <br><br>
            <label for="address">Address:</label>
            <textarea name="address" required><?php echo $address; ?></textarea>
            <br><br>
            <!-- Add other input fields for user information -->
            <input type="submit" value="Update Profile">
        </form>

        <div class="home-lobby-button">
            <a href="home_lobby.php">Home Lobby</a>
        </div>
    </div>
</body>
</html>

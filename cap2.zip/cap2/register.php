<?php
session_start();

// Handle the registration form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize input
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $contactNumber = $_POST['contact_number'];
    $password = $_POST['password'];

    // Perform necessary validation checks

    // Insert the user into the database
    $servername = 'localhost';
    $db_username = 'root';
    $db_password = '';
    $dbname = 'db_cs2';

    $conn = new mysqli($servername, $db_username, $db_password, $dbname);
    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    }

    // Check if the email already exists
    $checkUser = "SELECT * FROM users WHERE email='$email'";
    $result = $conn->query($checkUser);
    if ($result->num_rows > 0) {
        echo "Email already exists. Please choose a different email.";
        exit();
    }

    $sql = "INSERT INTO users (firstname, lastname, email, address, contact_number, password) VALUES ('$firstname', '$lastname', '$email', '$address', '$contactNumber', '$password')";
    if ($conn->query($sql) === true) {
        $_SESSION['username'] = $email;
        header('Location: home_lobby.php');
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <style>
        body {
            background-color: #349bdf;
            color: #fff;
            font-family: Arial, sans-serif;
            padding: 20px;
        }

        h2 {
            margin-bottom: 20px;
        }

        form {
            max-width: 400px;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"],
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: none;
            border-radius: 4px;
            background-color: #a7d3f1;
            color: #0a2b43;
        }

        input[type="submit"]:hover {
            background-color: #0a2b43;
            color: #fff;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .login-link {
            color: #fff;
            text-align: center;
        }
    </style>
</head>
<body>
    <h2>Register</h2>

    <!-- Registration form -->
    <form action="register.php" method="POST">
        <input type="text" name="firstname" placeholder="First Name" required><br>
        <input type="text" name="lastname" placeholder="Last Name" required><br>
        <input type="email" name="email" placeholder="Email" required><br>
        <input type="text" name="address" placeholder="Address" required><br>
        <input type="text" name="contact_number" placeholder="Contact Number" required><br>
        <input type="password" name="password" placeholder="Password" required><br>
        <input type="submit" value="Register">
    </form>

    <p class="login-link">Already have an account? <a href="login.php">Login</a></p>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
    <title>Waiting Page</title>
    <!-- Add your CSS styling here -->
    <style>
        /* Add your CSS styles for the waiting page */
    </style>
</head>
<body>
    <h1>Welcome, <?php echo $_SESSION['username']; ?>!</h1>
    <h2>Waiting for Contestant Entries</h2>
    <p>Event: <?php echo $event['title']; ?></p>

    <!-- Add additional content as desired -->

    <h3>Contestant Entries:</h3>
    <ul id="entryList">
        <!-- Entries will be dynamically added here using JavaScript -->
    </ul>

    <script>
        // Function to fetch new entries and update the page
        function fetchEntries() {
            // Make an AJAX request to the server to fetch new entries
            // You can use a library like jQuery or fetch API

            // Example using jQuery:
            $.ajax({
                url: 'fetch_entries.php',
                method: 'GET',
                data: { event_id: <?php echo $eventID; ?> },
                success: function(response) {
                    // Update the entry list with the new entries
                    $('#entryList').html(response);
                }
            });
        }

        // Fetch entries initially
        fetchEntries();

        // Fetch entries every 5 seconds (adjust the interval as needed)
        setInterval(fetchEntries, 5000);
    </script>
</body>
</html>

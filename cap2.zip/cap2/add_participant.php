<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the event ID and participant name from the form
    $eventId = $_POST['eventId'];
    $participantName = $_POST['participantName'];

    // Perform necessary validations and database operations to add the participant

    // Example code to add the participant to the event (replace with your actual implementation)
    $success = addParticipantToEvent($eventId, $participantName);

    // Check if participant addition was successful
    if ($success) {
        echo "<p>Participant '$participantName' has been added to the event.</p>";
    } else {
        echo "<p>Failed to add participant '$participantName' to the event.</p>";
    }
} else {
    // Redirect back to the create_event.php page if accessed directly without form submission
    header("Location: create_event.php");
    exit();
}

/**
 * Function to add a participant to an event.
 *
 * @param int    $eventId          The ID of the event.
 * @param string $participantName  The name of the participant.
 *
 * @return bool  True if the participant was successfully added, false otherwise.
 */
function addParticipantToEvent($eventId, $participantName)
{
    // Add your code here to perform the necessary database operations and add the participant to the event
    // Return true if participant addition is successful, false otherwise

    // Example code: Assuming you have a database connection established
    // You need to replace the placeholders with your actual table and column names

    // Insert the participant into the participants table
    $query = "INSERT INTO participants (event_id, participant_name) VALUES (?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("is", $eventId, $participantName);

    // Execute the query
    $success = $stmt->execute();

    // Close the statement
    $stmt->close();

    // Return the success status
    return $success;
}

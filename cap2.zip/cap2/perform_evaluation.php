<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

// Handle the evaluation form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize input
    $entryID = $_POST['entryID'];
    $evaluationLabel = $_POST['evaluationLabel'];
    $evaluationBadge = $_POST['evaluationBadge'];

    // Update the entry in the database with evaluation details
    $servername = 'localhost';
    $db_username = 'root';
    $db_password = '';
    $dbname = 'db_cs2';

    $conn = new mysqli($servername, $db_username, $db_password, $dbname);
    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    }

    $sql = "UPDATE entries SET evaluation_label='$evaluationLabel', evaluation_badge='$evaluationBadge' WHERE entry_id='$entryID'";
    if ($conn->query($sql) === true) {
        echo "Evaluation performed successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<!-- Evaluation form -->
<form action="perform_evaluation.php" method="POST">
    <input type="text" name="entryID" placeholder="Entry ID" required><br>
    <input type="text" name="evaluationLabel" placeholder="Evaluation Label" required><br>
    <input type="text" name="evaluationBadge" placeholder="Evaluation Badge" required><br>
    <input type="submit" value="Perform Evaluation">
</form>

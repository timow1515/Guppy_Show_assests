<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Perform necessary validations and database operations to create the event

    // Example code to create the event (replace with your actual implementation)
    // Assuming the event ID is obtained after successfully creating the event
    $eventId = createEvent();

    // Check if the event ID is obtained
    if ($eventId) {
        // Redirect the user to the modify_event.php page with the event ID included in the URL
        header("Location: modify_event.php?event_id=" . $eventId);
        exit();
    } else {
        echo "<p>Error creating the event.</p>";
    }
}

/**
 * Function to create an event in the database.
 *
 * @return int|false The ID of the created event if successful, false otherwise.
 */
function createEvent()
{
    // Add your code here to perform the necessary database operations and create the event
    // Return the ID of the created event if successful, false otherwise

    // Example code: Assuming you have a database connection established
    // You need to replace the placeholders with your actual database connection details
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "db_cs2";

    // Create a new database connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and execute the SQL query to insert the event details into the events table
    $query = "INSERT INTO events (title, description, max_participants, payment_amount, organizer_name, category) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssiiis", $title, $description, $maxParticipants, $paymentAmount, $organizerName, $category);

    // Assign values to the variables used in the bind_param function
    $title = $_POST['title'] ?? "";
    $description = $_POST['description'] ?? "";
    $maxParticipants = $_POST['max_participants'] ?? 0;
    $paymentAmount = $_POST['payment_amount'] ?? 0;
    $organizerName = $_POST['organizer_name'] ?? "";
    $category = $_POST['category'] ?? "";
    $stmt->execute();

    // Get the ID of the created event
    $eventId = $stmt->insert_id;

    // Close the statement and the database connection
    $stmt->close();
    $conn->close();

    // Return the event ID or false if event creation failed
    return $eventId ? $eventId : false;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Create Event</title>
    <style>
        body {
            background-color: #f1f1f1;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 500px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 4px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #0a2b43;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .form-group input[type="text"],
        .form-group input[type="number"],
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .form-group textarea {
            height: 100px;
        }

        .form-group .button-container {
            text-align: center;
        }

        .form-group .button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #0a2b43;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }

        .form-group .button:hover {
            background-color: #064976;
        }

        .back-button {
            text-align: center;
            margin-top: 20px;
        }

        .back-button .button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #0a2b43;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }

        .back-button .button:hover {
            background-color: #064976;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Create Event</h1>

        <form method="POST" action="create_event.php">
            <div class="form-group">
                <label for="title">Title:</label>
                <input type="text" name="title" id="title" required>
            </div>

            <div class="form-group">
                <label for="description">Description:</label>
                <textarea name="description" id="description" required></textarea>
            </div>

            <div class="form-group">
                <label for="max_participants">Max Participants:</label>
                <input type="number" name="max_participants" id="max_participants" required>
            </div>

            <div class="form-group">
                <label for="payment_amount">Payment Amount:</label>
                <input type="number" name="payment_amount" id="payment_amount" required>
            </div>

            <div class="form-group">
                <label for="organizer_name">Organizer Name:</label>
                <input type="text" name="organizer_name" id="organizer_name" required>
            </div>

            <div class="form-group">
                <label for="category">Category:</label>
                <input type="text" name="category" id="category" required>
            </div>

            <div class="form-group button-container">
                <input type="submit" class="button" value="Create">
            </div>
        </form>

        <div class="back-button">
            <a class="button" href="home_lobby.php">Back</a>
        </div>
    </div>
</body>
</html>

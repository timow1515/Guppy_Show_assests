<?php
// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $title = $_POST['title'];
    $description = $_POST['description'];
    $maxParticipants = $_POST['max_participants'];
    $paymentAmount = $_POST['payment_amount'];
    $organizerName = $_POST['organizer_name'];
    $category = $_POST['category'];

    // Validate form data (you can add your own validation rules here)

    // Connect to the database
    $servername = 'localhost';
    $username = 'root';
    $password = '';
    $dbname = 'db_cs2';

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    }

    // Insert event data into the database
    $sql = "INSERT INTO events (title, description, max_participants, payment_amount, organizer_name, category) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ssssss', $title, $description, $maxParticipants, $paymentAmount, $organizerName, $category);

    if ($stmt->execute()) {
        // Event created successfully
        echo 'Event created successfully';
        // Redirect to the home lobby or any other page you desire
        header('Location: home_lobby.php');
        exit();
    } else {
        // Error occurred while creating the event
        echo 'Error creating event: ' . $conn->error;
    }

    $stmt->close();
    $conn->close();
}
?>

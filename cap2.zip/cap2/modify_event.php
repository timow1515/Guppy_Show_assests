<?php
// Include the database connection code here
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_cs2";
// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve the event ID from the query string
$event_id = $_GET['event_id'];

// Fetch event details from the database
$sql = "SELECT * FROM events WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $event_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Event found, display the details and allow modification
    $event = $result->fetch_assoc();
    ?>

    <!DOCTYPE html>
    <html>
    <head>
        <title>Modify Event</title>
        <style>
            body {
                background-color: #f1f1f1;
                font-family: Arial, sans-serif;
                margin: 0;
                padding: 0;
            }

            .container {
                max-width: 500px;
                margin: 0 auto;
                padding: 20px;
                background-color: #fff;
                border-radius: 4px;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            }

            h1 {
                text-align: center;
                color: #0a2b43;
                margin-bottom: 20px;
            }

            .form-group {
                margin-bottom: 20px;
            }

            .form-group label {
                display: block;
                font-weight: bold;
                margin-bottom: 5px;
            }

            .form-group input[type="text"],
            .form-group input[type="number"],
            .form-group textarea {
                width: 100%;
                padding: 10px;
                border: 1px solid #ccc;
                border-radius: 4px;
            }

            .form-group textarea {
                height: 100px;
            }

            .form-group .button-container {
                text-align: center;
            }

            .form-group .button {
                display: inline-block;
                padding: 10px 20px;
                background-color: #0a2b43;
                color: #fff;
                text-decoration: none;
                border-radius: 4px;
                transition: background-color 0.3s ease;
            }

            .form-group .button:hover {
                background-color: #064976;
            }

            .back-button {
                text-align: center;
                margin-top: 20px;
            }

            .back-button .button {
                display: inline-block;
                padding: 10px 20px;
                background-color: #0a2b43;
                color: #fff;
                text-decoration: none;
                border-radius: 4px;
                transition: background-color 0.3s ease;
            }

            .back-button .button:hover {
                background-color: #064976;
            }
        </style>
    </head>
    <body>
    <div class="container">
        <h1>Modify Event</h1>
        <form action="process_modify_event.php" method="POST">
            <input type="hidden" name="event_id" value="<?php echo $event['id']; ?>">
            <div class="form-group">
                <label for="title">Title:</label>
                <input type="text" id="title" name="title" value="<?php echo $event['name']; ?>">
            </div>
            <div class="form-group">
                <label for="event_description">Event Description:</label>
                <textarea id="event_description" name="event_description"><?php echo $event['description']; ?></textarea>
            </div>
          <div class="form-group">
    <label for="participants">Participants:</label>
    <?php
    // Retrieve participants for the event from the database
    $sql = "SELECT * FROM participants WHERE event_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $event_id);
    $stmt->execute();
    $participants = $stmt->get_result();

    if ($participants->num_rows > 0) {
        while ($participant = $participants->fetch_assoc()) {
            echo '<div class="participant">';
            echo '<input type="text" name="participant_name[]" value="' . ($participant['name'] ?? '') . '">';
            echo '<input type="text" name="participant_email[]" value="' . ($participant['email'] ?? '') . '">';
            echo '<a href="#" class="remove-participant">Remove</a>';
            echo '</div>';
        }
    } else {
        echo '<p>No participants added yet.</p>';
    }

    ?>
    <div id="participant-container"></div>
    <button id="add-participant-button" type="button">Add Participant</button>
</div>

            <div class="form-group button-container">
                <input type="submit" class="button" value="Save Changes">
            </div>
        </form>
        <div class="back-button">
            <a href="javascript:history.back()" class="button">Back</a>
        </div>
    </div>

    <script>
        // Add participant functionality
        document.getElementById('add-participant-button').addEventListener('click', function () {
            var participantContainer = document.getElementById('participant-container');
            var newParticipantDiv = document.createElement('div');
            newParticipantDiv.className = 'participant';
            newParticipantDiv.innerHTML = '<input type="text" name="participant_name[]" placeholder="Name">' +
                '<input type="text" name="participant_email[]" placeholder="Email">' +
                '<a href="#" class="remove-participant">Remove</a>';
            participantContainer.appendChild(newParticipantDiv);
        });

        // Remove participant functionality
        document.addEventListener('click', function (event) {
            if (event.target.classList.contains('remove-participant')) {
                event.preventDefault();
                var participantDiv = event.target.parentNode;
                participantDiv.parentNode.removeChild(participantDiv);
            }
        });
    </script>
    </body>
    </html>

    <?php
} else {
    // Event not found, display an error message
    echo "Event not found.";
}

$stmt->close();
$conn->close();
?>

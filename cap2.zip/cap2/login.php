<?php
session_start();

// Check if the user is already logged in
if (isset($_SESSION['username'])) {
    header('Location: home_lobby.php');
    exit();
}

// Handle the login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize input
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Check email and password against the database
    $servername = 'localhost';
    $db_username = 'root';
    $db_password = '';
    $dbname = 'db_cs2';

    $conn = new mysqli($servername, $db_username, $db_password, $dbname);
    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    }

    $sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
    $result = $conn->query($sql);

    if ($result->num_rows === 1) {
        $_SESSION['username'] = $email;
        header('Location: home_lobby.php');
        exit();
    } else {
        echo "Invalid email or password";
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <style>
        body {
            background-color: #349bdf;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .container {
            background-color: #fff;
            border-radius: 8px;
            padding: 40px;
            width: 400px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
            color: #0a2b43;
        }

        form {
            margin-top: 20px;
        }

        input[type="email"],
        input[type="password"],
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: none;
            border-radius: 4px;
            background-color: #a7d3f1;
            color: #0a2b43;
        }

        input[type="submit"]:hover {
            background-color: #0a2b43;
            color: #fff;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .register-link {
            text-align: center;
            color: #0a2b43;
        }

        .register-link a {
            color: #0a2b43;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Guppy Show Contest</h1>

        <form action="login.php" method="POST">
            <input type="email" name="email" placeholder="Email" required><br>
            <input type="password" name="password" placeholder="Password" required><br>
            <input type="submit" value="Login">
        </form>

        <p class="register-link">Don't have an account? <a href="register.php">Register</a></p>
    </div>
</body>
</html>
